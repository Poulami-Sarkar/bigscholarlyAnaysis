use bsd;
select paper_id as Paper_ID ,paper_title as Paper_Title ,paper_year as Published_Year from Papers_AI order by rand() limit 10;

insert into Paper_Author_AM values(6969,'1',6969);
delete from Paper_Author_AM where paper_ID = '6969';

#STORED PROCEDURES
DELIMITER //
CREATE PROCEDURE Show_tables()
BEGIN 
 show full tables where Table_Type = 'BASE TABLE';
 END//
DELIMITER;

DELIMITER //;
call Show_tables();

#Trigger
drop trigger increase_count;
DELIMITER $$
create trigger increase_count 
after insert  on Paper_Author_AM  
for each row
BEGIN
IF 
	NOT EXISTS ( SELECT  *
            FROM Author_Paper_Count_AM   
            WHERE   new.author_ID = author_ID)
THEN
	BEGIN
		insert into Author_Paper_Count_AM values (new.author_ID,NULL,1);
	END;
else
update Author_Paper_Count_AM set paper_count = paper_count + 1 where new.author_ID = author_ID;

END IF;

END$$
DELIMITER ;

drop trigger decrease_count;
DELIMITER $$
create trigger decrease_count 
after delete  on Paper_Author_AM  
for each row
BEGIN
IF 
	EXISTS ( SELECT  *
            FROM Author_Paper_Count_AM   
            WHERE   old.author_ID = author_ID and paper_count = 1)
THEN
	BEGIN
		delete from Author_Paper_Count_AM where old.author_ID = author_ID;
	END;
else
update Author_Paper_Count_AM set paper_count = paper_count - 1 where old.author_ID = author_ID;

END IF;

END$$
DELIMITER ;

#VIEWS
create view AM as (
select paper_year, t1.paper_ID,am_citations,authors  from (select pai.paper_year, pai.paper_ID, count(ai.paper_cite_id) am_citations 
from Papers_AM pai left join Paper_Citations_AM ai on ai.paper_id =pai.paper_id
where pai.paper_year >1970 
group by pai.paper_id)t1 left join 
(
SELECT paa.paper_ID,COUNT(distinct author_ID) authors
 from Paper_Author_AM paa, Papers_AM p
 where paa.paper_ID =p.paper_ID and paper_year>1970
 group by (paa.paper_ID)
 ) t2 on t1.paper_ID =t2.paper_ID order by paper_year
 );

drop view SE;
create view SE as (
select paper_published_year as paper_year, t1.paper_ID,se_citations,authors  from (select pai.paper_published_year, pai.paper_ID, count(ai.paper_cite_id) se_citations 
from Papers_SE pai left join Paper_Citations_SE ai on ai.paper_id =pai.paper_id
where pai.paper_published_year >1970 
group by pai.paper_id)t1 left join 
(
SELECT paa.paper_ID,COUNT(distinct author_ID) authors
 from Paper_Author_Affiliations_SE paa, Papers_SE p
 where paa.paper_ID =p.paper_ID and paper_published_year>1970
 group by (paa.paper_ID)
 ) t2 on t1.paper_ID =t2.paper_ID order by paper_published_year
 );
 
drop view Citations_AI;
create view Citations_AI as (
select pc.paper_ID, pc.paper_cite_ID, p1.paper_year , p2.paper_year paper_cite_published_year 
from Paper_Citations_AI pc , Papers_AI p1,Papers_AI p2 
where p1.paper_id = pc.paper_ID and pc.paper_cite_ID = p2.paper_id
);