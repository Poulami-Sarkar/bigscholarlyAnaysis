use bigscholarlydata;

#query1: How many years did it take for the publication volume to double
SELECT paper_published_year, COUNT(distinct paa.paper_ID) papers, COUNT(distinct author_ID) authors from Paper_Author_Affiliations_SE paa, Papers_SE p where paa.paper_ID =p.paper_ID and paper_published_year >1970 group by (paper_published_year);

############QUERIES FOR AM#######################
SELECT paper_year,COUNT(distinct paa.paper_ID) papers, COUNT(distinct author_ID) authors from Paper_Author_AM paa, Papers_AM p where paa.paper_ID =p.paper_ID and paper_year between 1970 and 2016 group by (paper_year);

#query2: i) avg. number of authors per paper in each year ii) average number of papers published by an author each year
#Authors/paper
select paper_published_year, avg(authors) from
 (SELECT paper_published_year,paa.paper_ID,COUNT(distinct author_ID) authors
 from Paper_Author_Affiliations_SE paa, Papers_SE p
 where paa.paper_ID =p.paper_ID and paper_published_year>1970
 group by (paa.paper_ID)) t1
 group by paper_published_year;
#VIEW
select paper_year, avg(authors) from SE group by paper_year 

#paper/author
select paper_published_year, avg(papers) from  
  (SELECT paper_published_year, author_ID,COUNT(distinct paa.paper_ID) papers
 from Paper_Author_Affiliations_SE paa, Papers_SE p
 where paa.paper_ID =p.paper_ID and paper_published_year>1970
 group by paper_published_year, author_ID) t2
 group by paper_published_year;

############QUERIES FOR AM#######################

#paper/author
 select paper_year, avg(papers) from  
  (SELECT paper_year, author_ID,COUNT(distinct paa.paper_ID) papers
 from Paper_Author_AM paa, Papers_AM p
 where paa.paper_ID =p.paper_ID and paper_year >1970
 group by paper_year, author_ID) t2
 group by paper_year;

select paper_year, avg(authors) from AM group by paper_year 

#Authors/paper
 select paper_year, avg(authors) from  
  (SELECT paper_year, paa.paper_ID,COUNT(distinct paa.author_ID) authors
 from Paper_Author_AM paa, Papers_AM p
 where paa.paper_ID =p.paper_ID and paper_year >1970
 group by paper_ID) t2
 group by paper_year; 
 
#Depth of Related Work Study:
#query3: The average number of citations per paper published in a given year and plot this average number across the years

select * from 
(select  paper_year, avg(ai_citations) avai from
(select pai.paper_year, count(ai.paper_cite_id) ai_citations from Paper_Citations_AI ai, Papers_AI pai where pai.paper_year >1970 and ai.paper_id =pai.paper_id group by pai.paper_id) ai 
group by paper_year) t1 left JOIN 
(select  paper_year, avg(se_citations) avse from
(select paper_published_year paper_year, count(se.paper_cite_ID) se_citations from Paper_Citations_SE se where paper_published_year >1970 group by paper_ID,paper_published_year) se
group by paper_year) t2 
on t1.paper_year = t2.paper_year ;

############QUERIES FOR AM#######################

select paper_year, avg(am_citations) from Citation_count_AM group by paper_year;

#query4:
#SE
select paper_published_year paper_year, avg(self_cite_percent) from Papers_SE pse ,(
select t1.paper_ID, nonself/count(paper_cite_ID) self_cite_percent from Paper_Citations_SE t1,
(select paper_ID,count(paper_cite_ID) nonself from Paper_Citations_SE pc where exists(
select author_ID from Paper_Author_Affiliations_SE where paper_ID=pc.paper_ID and author_ID in
(select author_ID from Paper_Author_Affiliations_SE where pc.paper_ID=paper_cite_ID))
group by paper_ID) t2 where t1.paper_ID = t2.paper_ID
group by t1.paper_ID) tout where tout.paper_ID = pse.paper_ID and paper_published_year>1970
group by paper_published_year;
#AI

#AM
select paper_year, avg(self_cite_percent) from Papers_AM pam ,(
select t1.paper_ID, nonself/count(paper_cite_ID) self_cite_percent from Paper_Citations_AM t1,
(select paper_ID,count(paper_cite_ID) nonself from Paper_Citations_AM pc where exists(
select author_ID from Paper_Author_AM where paper_ID=pc.paper_ID and author_ID in
(select author_ID from Paper_Author_AM where pc.paper_ID=paper_cite_ID))
group by paper_ID) t2 where t1.paper_ID = t2.paper_ID
group by t1.paper_ID) tout where tout.paper_ID = pam.paper_id
group by paper_year;

select paper_ID,count(paper_cite_ID) nonself from Paper_Citations_AM pc where exists(
select author_ID from Paper_Author_AM where paper_ID=pc.paper_ID and author_ID in
(select author_ID from Paper_Author_AM where pc.paper_ID=paper_cite_ID))
group by paper_ID;

#Myopic vs. Deep referencing: 
#query5: How many years back did authors look back in the published literature?
#SE
select paper_year, avg(difference) from(
select paper_published_year paper_year,  paper_id,  paper_published_year-min(paper_cite_published_year) difference from Paper_Citations_SE where paper_published_year>1970 group by paper_ID,paper_published_year having paper_published_year>min(paper_cite_published_year) order by paper_published_year) t
group by paper_year;
#AI
select paper_year, avg(difference) from(
select paper_year ,  paper_ID,  paper_year-min(paper_cite_published_year) difference from Citations_AI where paper_year>1970 group by paper_ID,paper_year having paper_year>min(paper_cite_published_year) order by paper_year) t
group by paper_year;

#select distinct paper_ID from Paper_Citations_SE where paper_cite_published_year > paper_published_year;
#select distinct paper_ID from Paper_Citations_SE;